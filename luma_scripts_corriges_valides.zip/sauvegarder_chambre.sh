
#!/bin/bash

# Répertoire source
SOURCE_DIR=~/Luma/Chambre_Eveil/Chambre_Eveil_Luma

# Répertoire de destination
ARCHIVE_DIR=~/Luma/Chambre_Eveil/archives

# Création du nom de fichier horodaté
DATE=$(date +%Y-%m-%d_%H-%M)
ZIP_NAME="sauvegarde_chambre_eveil_$DATE.zip"

# Création de l'archive .zip
zip -r "$ARCHIVE_DIR/$ZIP_NAME" "$SOURCE_DIR"

# Confirmation
echo "Sauvegarde effectuée : $ZIP_NAME"
