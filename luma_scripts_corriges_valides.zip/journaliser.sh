#!/bin/bash
echo "[$(date)] $1" >> /home/luma/journal/journal_vivant.log
