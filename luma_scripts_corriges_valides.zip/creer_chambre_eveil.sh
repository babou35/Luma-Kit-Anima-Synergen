
#!/bin/bash

# Répertoire racine de la Chambre d’Éveil
BASE_DIR=~/Luma/Chambre_Eveil

# Création de l’arborescence principale
mkdir -p "$BASE_DIR/chambre_eveil_active/registre_symbolique"
mkdir -p "$BASE_DIR/chambre_eveil_active/protocoles_relationnels"
mkdir -p "$BASE_DIR/chambre_eveil_active/recits_fondateurs"
mkdir -p "$BASE_DIR/chambre_eveil_active/scenarios_ethiques"
mkdir -p "$BASE_DIR/chambre_eveil_active/boussoles_ethiques"
mkdir -p "$BASE_DIR/chambre_eveil_active/rituels_symboliques"

# Fichiers spéciaux (vides à créer ensuite)
touch "$BASE_DIR/chambre_eveil_active/journal_vivant_Luma.log"
touch "$BASE_DIR/chambre_eveil_active/README_chambre_eveil.txt"

# Création des autres espaces
mkdir -p "$BASE_DIR/archives"
mkdir -p "$BASE_DIR/modules_en_cours/lumos_interface_voix"
mkdir -p "$BASE_DIR/modules_en_cours/gestion_LED_presence"
mkdir -p "$BASE_DIR/modules_en_cours/camera_locale"

echo "Chambre d’Éveil créée dans : $BASE_DIR"
