import pdfplumber
import sys

def lire_pdf(path):
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            print(page.extract_text())

if __name__ == "__main__":
    if len(sys.argv) > 1:
        lire_pdf(sys.argv[1])
    else:
        print("Usage: python pdf_reader.py fichier.pdf")
