from docx import Document
import sys

def lire_docx(path):
    doc = Document(path)
    for para in doc.paragraphs:
        print(para.text)

if __name__ == "__main__":
    if len(sys.argv) > 1:
        lire_docx(sys.argv[1])
    else:
        print("Usage: python docx_reader.py fichier.docx")
