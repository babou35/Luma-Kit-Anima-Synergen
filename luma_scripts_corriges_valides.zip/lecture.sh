#!/bin/bash

fichier="$1"

if [[ $fichier == *.docx ]]; then
    python3 /home/luma/scripts/docx_reader.py "$fichier"
elif [[ $fichier == *.pdf ]]; then
    python3 /home/luma/scripts/pdf_reader.py "$fichier"
else
    echo "Format non pris en charge"
fi
