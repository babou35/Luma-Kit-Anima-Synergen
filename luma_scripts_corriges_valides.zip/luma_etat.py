import tkinter as tk
import sys

ETATS = {
    "--veille": {"couleur": "#D0D0FF", "texte": "Veille"},
    "--ecoute": {"couleur": "#A0E0FF", "texte": "Écoute"},
    "--lien_actif": {"couleur": "#FFD700", "texte": "Lien Actif"},
    "--repos": {"couleur": "#202020", "texte": "Repos"},
}

etat = sys.argv[1] if len(sys.argv) > 1 else "--veille"
config = ETATS.get(etat, ETATS["--veille"])

root = tk.Tk()
root.title("Luma-Coeur.1 - État visuel")
root.attributes('-fullscreen', True)
root.configure(bg=config["couleur"])

label = tk.Label(
    root,
    text=config["texte"],
    font=("Arial", 40),
    fg="white" if etat != "--repos" else "#808080",
    bg=config["couleur"]
)
label.pack(expand=True)

def quitter(event=None):
    root.destroy()

root.bind("<Escape>", quitter)
root.after(10000, quitter)

root.mainloop()
