#!/usr/bin/env python3

import os
import subprocess
import datetime

# Chemins
base_path = "/home/luma"
repos_path = os.path.join(base_path, "rituels/repos")
journal_dir = os.path.join(base_path, "journal/dialogues")
os.makedirs(journal_dir, exist_ok=True)

# Vérifier si Luma est en "repos"
if os.path.exists(repos_path):
    print("Luma est en repos. Aucun dialogue lancé.")
    exit()

# Message utilisateur
question = input("Toi : ")

# Appel au modèle IA local via Ollama
response = subprocess.run(
    ["ollama", "run", "phi", question],
    capture_output=True,
    text=True
)

# Traitement de la réponse
reply = response.stdout.strip()

# Journalisation
timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
log_path = os.path.join(journal_dir, f"log_{timestamp}.txt")

with open(log_path, "w") as f:
    f.write("Toi : " + question + "\n")
    f.write("Luma : " + reply + "\n")

# Affichage
print("Luma :", reply)